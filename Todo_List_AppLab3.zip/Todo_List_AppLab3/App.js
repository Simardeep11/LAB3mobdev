import React, { useState } from 'react';
import ToDoList from "./Component/ToDoList";
import ToDoForm from "./Component/ToDoForm";
import { View, StyleSheet } from 'react-native';

const App = () => {
    const [tasks, setTasks] = useState([
      { text: 'Do laundry', completed: false },
      { text: 'Go to gym', completed: false },
      { text: 'Walk dog', completed: false },
    ]);

    const addTask = (taskText) => {
      setTasks([...tasks, { text: taskText, completed: false }]);
    };

    return (
      <View style={styles.container}>
        <ToDoList tasks={tasks} />
        <ToDoForm addTask={addTask} />
      </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingTop: 20,
        paddingHorizontal: 10,
        backgroundColor: '#fff',
    },
});

export default App;
